Ace-Enchanted_booksをダウンロードしていただきありがとうございます。
Ace-Enchanted_booksはVisual Enchantmentsを改変して製作されました。

RedStonePlusの変更はご自由にしていただいて構いません。

動画等で使用の際記載はしなくても大丈夫ですが、
収益が発生する場合はこちらのURLを記載してください: https://acs-hp.netlify.app/

リソースパックを使用するにはOptiFineが必要です。
このリソースパックの再頒布を禁止します。

エンチャント本を金床で組み合わせた際、テクスチャは優先度の高い方になります。
このリソースパックで不具合等が起こりましても制作陣は一切責任を負いかねます。

---- VERSIONS ------------------
Minecraft1.18向けに製作されています。
動作確認済みバージョン        : 1.18.1
動作する可能性が高いバージョン: 1.15～1.17.1
動作する可能性が低いバージョン: 1.12未満
--------------------------------

---- LINKS ---------------------
Visual Enchantments: https://www.curseforge.com/minecraft/texture-packs/visual-enchantments
AceCoreSystems     : https://acs-hp.netlify.app/
--------------------------------

---- COPYRIGHT -----------------
Texture        : はっ
ResoucePackEdit: sou
--------------------------------